﻿When uploading your extension to the Chrome Web Store, you can add screenshots
that will be presented on the download page at the store. Use this folder for your
screenshots.

The Web Store is located here: https://chrome.google.com/webstore/category/extensions